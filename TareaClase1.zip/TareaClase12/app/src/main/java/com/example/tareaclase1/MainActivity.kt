package com.example.tareaclase1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    var nn1 = Random.nextInt(0,100)
    var nn2 = Random.nextInt(0,100)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val texto1 = findViewById(R.id.text1) as TextView
        texto1.setText("")

        val boton1 = findViewById(R.id.button1) as Button
        boton1.setText(nn1.toString())
        boton1.setOnClickListener {

                check(nn1,nn2,texto1)
                nn1 =  Random.nextInt(0,100)
                boton1.setText(nn1.toString())
        }
        val boton2 = findViewById(R.id.button2) as Button
        boton2.setText(nn2.toString())
        boton2.setOnClickListener {
            check(nn2,nn1,texto1)
            nn2 =  Random.nextInt(0,100)
            boton2.setText(nn2.toString())
        }


    }
    fun check(n1:Int, n2:Int,txt:TextView)
    {
        if (n1 > n2){
            txt.setText("Muy bien")
        }
        else{
            txt.setText("Muy mal")
        }
    }


}
